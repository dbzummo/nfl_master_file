#!/usr/bin/env python3
"""
make_model_lines_and_board.py

Join predictions + market data, normalize probability + game_id columns,
and render board_week.html.

Fixes:
- Probability column mismatch: [p_home, p_home_model, cal_platt] -> p_home
- Game ID mismatch: [msf_game_id, game_id, gid, game] -> msf_game_id

Prime Directive: Accuracy and reproducibility.
"""

import pandas as pd
from pathlib import Path

# Inputs
PRED_FILE = Path("out/week_predictions.csv")
MARKET_FILE = Path("out/week_with_market.csv")

# Outputs
OUT_CSV = Path("out/model_board.csv")
OUT_HTML = Path("reports/board_week.html")


def load_predictions() -> pd.DataFrame:
    df = pd.read_csv(PRED_FILE)

    # normalize probability column
    if "p_home" not in df.columns:
        if "p_home_model" in df.columns:
            print("[INFO] Renaming p_home_model -> p_home")
            df.rename(columns={"p_home_model": "p_home"}, inplace=True)
        elif "cal_platt" in df.columns:
            print("[INFO] Renaming cal_platt -> p_home")
            df.rename(columns={"cal_platt": "p_home"}, inplace=True)
        else:
            raise KeyError(
                f"[FATAL] No probability column found in {PRED_FILE}. "
                "Expected one of: p_home, p_home_model, cal_platt."
            )

    # normalize game id column
    id_map = {
        "msf_game_id": "msf_game_id",
        "game_id": "msf_game_id",
        "gid": "msf_game_id",
        "game": "msf_game_id",
    }
    found = False
    for col in list(df.columns):
        if col in id_map and col != "msf_game_id":
            print(f"[INFO] Renaming {col} -> msf_game_id")
            df.rename(columns={col: "msf_game_id"}, inplace=True)
            found = True
            break
        elif col == "msf_game_id":
            found = True
            break
    if not found:
        raise KeyError(
            f"[FATAL] No game id column found in {PRED_FILE}. "
            f"Expected one of: {list(id_map.keys())}."
        )

    return df


def main():
    print("[INFO] Loading predictions and market data...")
    preds = load_predictions()
    market = pd.read_csv(MARKET_FILE)

    if "msf_game_id" not in market.columns:
        raise KeyError("[FATAL] msf_game_id missing in market file.")

    print("[INFO] Joining predictions with market...")
    df = preds.merge(market, on="msf_game_id", how="inner")

    # derive edge
    if "market_p_home" in df.columns:
        df["edge"] = df["p_home"] - df["market_p_home"]
    else:
        print("[WARN] market_p_home missing; edge not computed.")

    # write CSV
    OUT_CSV.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(OUT_CSV, index=False)
    print(f"[OK] Wrote joined model board CSV -> {OUT_CSV}")

    # render HTML
    OUT_HTML.parent.mkdir(parents=True, exist_ok=True)
    df.to_html(OUT_HTML, index=False)
    print(f"[OK] Rendered HTML board -> {OUT_HTML}")


if __name__ == "__main__":
    main()