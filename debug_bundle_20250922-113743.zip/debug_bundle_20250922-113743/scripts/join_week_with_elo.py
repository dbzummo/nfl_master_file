#!/usr/bin/env python3
"""
join_week_with_elo.py

Robust join step that:
- Auto-discovers the MSF weekly games CSV from multiple locations.
- Allows explicit override with --games PATH.
- Produces out/week_with_elo.csv (and keeps path behavior stable).

This avoids fragile assumptions like only "msf_week.csv" in CWD.
"""

import argparse
from pathlib import Path
import sys
import pandas as pd

CANDIDATES = [
    Path("msf_week.csv"),
    Path("week_games.csv"),
    Path("out/msf_week.csv"),
    Path("out/week_games.csv"),
    Path("out/msf/week_games.csv"),
    Path(__file__).resolve().parent / "msf_week.csv",
    Path(__file__).resolve().parent / "week_games.csv",
]

def find_games_csv(override: str | None) -> Path:
    if override:
        p = Path(override)
        if p.is_file():
            return p
        print(f"[FATAL] --games path not found: {p}", file=sys.stderr)
        sys.exit(1)
    for p in CANDIDATES:
        if p.is_file():
            print(f"[INFO] Using games baseline: {p}")
            return p
    print("[FATAL] No games baseline found. Tried:", file=sys.stderr)
    for p in CANDIDATES:
        print(f"  - {p}", file=sys.stderr)
    sys.exit(1)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--games", help="Path to games CSV (overrides autodetect)")
    ap.add_argument("--elo", default="cache/elo_ratings.csv", help="Path to ELO table")
    ap.add_argument("--hfa", default="cache/hfa.csv", help="Path to home-field adv csv")
    ap.add_argument("--out", default="out/week_with_elo.csv", help="Output CSV")
    args = ap.parse_args()

    games_csv = find_games_csv(args.games)

    # ---- Load inputs (minimal example; adapt columns to your model) ----
    games = pd.read_csv(games_csv)
    # Ensure a stable game id column
    for col in ("msf_game_id","game_id","gid","game"):
        if col in games.columns:
            if col != "msf_game_id":
                games = games.rename(columns={col:"msf_game_id"})
            break
    else:
        raise KeyError("No game id column in games csv (expected one of msf_game_id, game_id, gid, game)")

    # Optional: load ELO/HFA if your pipeline uses them; otherwise create stubs
    try:
        elo = pd.read_csv(args.elo)
    except FileNotFoundError:
        elo = pd.DataFrame()

    try:
        hfa = pd.read_csv(args.hfa)
    except FileNotFoundError:
        hfa = pd.DataFrame()

    # For now, just pass games through; your existing logic can replace this block.
    out_df = games.copy()

    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    out_df.to_csv(args.out, index=False)
    print(f"[OK] wrote {args.out} (rows={len(out_df)})")

if __name__ == "__main__":
    main()
