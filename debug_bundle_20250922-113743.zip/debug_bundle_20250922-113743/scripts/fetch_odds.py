#!/usr/bin/env python3
"""
Composite odds fetcher:
1) Try The Odds API for upcoming/live.
2) If zero rows AND SPORTSDATAIO_API_KEY is set, fall back to SportsDataIO weekly odds (historical-friendly).
Writes: out/odds_week.csv
"""
from __future__ import annotations
import os, sys, csv, math, json
from pathlib import Path
from datetime import datetime
import urllib.request
import urllib.parse

OUT = Path("out/odds_week.csv")

# ---- env / config ----
ODDS_API_KEY   = os.getenv("ODDS_API_KEY")
ODDS_API_BASE  = os.getenv("ODDS_API_BASE", "https://api.the-odds-api.com/v4/sports")
ODDS_API_SPORT = os.getenv("ODDS_API_SPORT", "americanfootball_nfl")
ODDS_API_REG   = os.getenv("ODDS_API_REGIONS", "us")
ODDS_API_MKTS  = os.getenv("ODDS_API_MARKETS", "h2h,spreads")
ODDS_API_FMT   = os.getenv("ODDS_API_ODDS_FORMAT", "american")
START          = os.getenv("START")
END            = os.getenv("END")

SDIO_KEY    = os.getenv("SPORTSDATAIO_API_KEY") or os.getenv("SDIO_API_KEY")
SDIO_BASE   = os.getenv("SDIO_API_BASE", "https://api.sportsdata.io/v3/nfl/odds/json")
SDIO_SEASON = os.getenv("SDIO_SEASON", "2025")   # e.g. "2025" or "2025POST"

def http_get(url, headers=None, timeout=30):
    req = urllib.request.Request(url, headers=headers or {})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        data = resp.read()
        return json.loads(data.decode("utf-8"))

def american_to_prob(ml):
    """Convert American moneyline to implied home win probability (0..1)."""
    if ml is None:
        return None
    try:
        ml = float(ml)
    except Exception:
        return None
    if ml == 0:
        return None
    if ml > 0:
        return 100.0 / (ml + 100.0)
    else:
        return (-ml) / ((-ml) + 100.0)

def row_from_oddsapi_event(ev):
    # Odds API v4 event layout (simplified/tolerant)
    try:
        home = (ev.get("home_team") or "").strip()
        away = (ev.get("away_team") or "").strip()
        commence = ev.get("commence_time")
        books = ev.get("bookmakers") or []
        ml_home = ml_away = None

        for bk in books:
            mkts = bk.get("markets") or []
            for m in mkts:
                if m.get("key") == "h2h":
                    outcomes = m.get("outcomes") or []
                    for o in outcomes:
                        name = (o.get("name") or "").strip()
                        price = o.get("price")
                        if name == home:
                            ml_home = price
                        elif name == away:
                            ml_away = price

        p_home = american_to_prob(ml_home)
        return {
            "home_abbr": home, "away_abbr": away, "commence_time": commence,
            "book_count": len(books), "ml_home": ml_home, "ml_away": ml_away,
            "market_p_home": p_home
        }
    except Exception:
        return None

def fetch_oddsapi_upcoming():
    if not ODDS_API_KEY:
        return []
    q = {
        "regions": ODDS_API_REG,
        "markets": ODDS_API_MKTS,
        "oddsFormat": ODDS_API_FMT,
        "apiKey": ODDS_API_KEY,
    }
    url = f"{ODDS_API_BASE}/{ODDS_API_SPORT}/odds?{urllib.parse.urlencode(q)}"
    data = http_get(url)
    rows = []
    for ev in (data or []):
        r = row_from_oddsapi_event(ev)
        if r: rows.append(r)
    return rows

# ---- SportsDataIO fallback (historical-friendly) ----

def sdio_get(path):
    if not SDIO_KEY:
        raise RuntimeError("SPORTSDATAIO_API_KEY not set")
    sep = "&" if "?" in path else "?"
    url = f"{SDIO_BASE}/{path}{sep}key={urllib.parse.quote(SDIO_KEY)}"
    return http_get(url, headers={"User-Agent": "nfl-master-file/1.0"})

def first_or_none(*values):
    for v in values:
        if v is not None:
            return v
    return None

def prob_from_two(ml_home, ml_away):
    p_h = american_to_prob(ml_home)
    p_a = american_to_prob(ml_away)
    # If only one side available, return that; if both, renormalize a bit
    if p_h is not None and p_a is not None:
        denom = p_h + p_a
        if denom > 0:
            return p_h / denom
        return p_h
    return p_h if p_h is not None else (1.0 - p_a if p_a is not None else None)

def sdio_rows_from_game(game):
    """
    Tries to extract a single moneyline snapshot per game from SDIO structure.
    SDIO objects commonly include PregameOdds (list) with MoneyLineHome / MoneyLineAway.
    """
    home = (game.get("HomeTeam") or "").strip()
    away = (game.get("AwayTeam") or "").strip()
    commence = game.get("Date") or game.get("Day") or game.get("GameStart")
    pre = game.get("PregameOdds") or game.get("PregameOddsList") or []

    ml_home = ml_away = None
    # choose first book with both sides or any available side
    for o in pre:
        mlh = first_or_none(o.get("MoneyLineHome"), o.get("HomeMoneyLine"))
        mla = first_or_none(o.get("MoneyLineAway"), o.get("AwayMoneyLine"))
        if mlh is not None or mla is not None:
            ml_home = ml_home if ml_home is not None else mlh
            ml_away = ml_away if ml_away is not None else mla
            if ml_home is not None and ml_away is not None:
                break

    p_home = prob_from_two(ml_home, ml_away)
    return {
        "home_abbr": home, "away_abbr": away, "commence_time": commence,
        "book_count": len(pre), "ml_home": ml_home, "ml_away": ml_away,
        "market_p_home": p_home
    }

def fetch_sdio_week(week: int):
    """
    Calls GameOddsByWeek/{season}/{week} (historical-friendly).
    """
    path = f"GameOddsByWeek/{SDIO_SEASON}/{int(week)}"
    data = sdio_get(path)
    rows = []
    for g in (data or []):
        try:
            r = sdio_rows_from_game(g)
            if r: rows.append(r)
        except Exception:
            continue
    return rows

# ---- main flow ----

def write_rows(rows):
    OUT.parent.mkdir(parents=True, exist_ok=True)
    cols = ["home_abbr","away_abbr","commence_time","book_count","ml_home","ml_away","market_p_home"]
    with OUT.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k) for k in cols})
    print(f"[OK] Wrote {OUT} (rows={len(rows)})")

def main():
    # optional week arg (preferred for SDIO)
    week = None
    if len(sys.argv) >= 2 and sys.argv[1].strip().isdigit():
        week = int(sys.argv[1].strip())

    # 1) try Odds API (only useful for upcoming/live)
    rows = []
    if ODDS_API_KEY:
        try:
            rows = fetch_oddsapi_upcoming()
            if rows:
                print("[INFO] Using The Odds API (upcoming/live).")
        except Exception as e:
            print(f"[WARN] Odds API error: {e}.", file=sys.stderr)

    # 2) fallback to SDIO weekly if no rows
    if not rows and SDIO_KEY:
        if week is None:
            # attempt to infer from env WEEK or START
            try:
                week = int(os.getenv("WEEK") or "")
            except Exception:
                pass
        if week is None:
            print("[INFO] No week provided; SDIO fallback skipped.")
        else:
            try:
                rows = fetch_sdio_week(week)
                if rows:
                    print(f"[INFO] Using SportsDataIO weekly odds (season={SDIO_SEASON}, week={week}).")
            except Exception as e:
                print(f"[WARN] SportsDataIO error: {e}.", file=sys.stderr)

    # 3) final: if still nothing, write empty (pipeline continues)
    if not rows:
        print("[WARN] No odds rows returned; writing empty CSV.")
    write_rows(rows)

if __name__ == "__main__":
    main()
