#!/usr/bin/env python3
"""
ensure_week_predictions.py

Create or repair out/week_predictions.csv, guaranteeing it has a probability
column: one of [p_home, p_home_model, cal_platt].

Priority for source:
  1) out/week_with_market.csv
  2) out/week_with_elo.csv

If probs missing:
  - If Elo columns exist, synthesize p_home_model via logistic(EloHome - EloAway + HFA).
  - Else, set p_home_model = 0.5 (neutral fallback).

Use --force to rebuild even if out/week_predictions.csv already exists.
"""
from __future__ import annotations
from pathlib import Path
import argparse, sys, math
import pandas as pd

MARKET = Path("out/week_with_market.csv")
ELO    = Path("out/week_with_elo.csv")
PREDS  = Path("out/week_predictions.csv")

def has_prob(df: pd.DataFrame) -> bool:
    return any(c in df.columns for c in ("p_home","p_home_model","cal_platt"))

def synthesize_from_elo(df: pd.DataFrame) -> bool:
    cand_h = [c for c in ("elo_home","eloHome","home_elo","elo_h","homeElo") if c in df.columns]
    cand_a = [c for c in ("elo_away","eloAway","away_elo","elo_a","awayElo") if c in df.columns]
    if not (cand_h and cand_a):
        return False
    eh, ea = cand_h[0], cand_a[0]
    # HFA optional; if per-row HFA column exists, use it; else default 60
    hfa_col = next((c for c in ("hfa","HFA","home_field","home_field_elo") if c in df.columns), None)
    def elo_prob(d):
        return 1.0 / (1.0 + math.pow(10.0, -d/400.0))
    if hfa_col and pd.api.types.is_numeric_dtype(df[hfa_col]):
        df["p_home_model"] = (df[eh] - df[ea] + df[hfa_col].fillna(60.0)).apply(elo_prob)
    else:
        df["p_home_model"] = (df[eh] - df[ea] + 60.0).apply(elo_prob)
    print("[INFO] Synthesized p_home_model from Elo columns.")
    return True

def ensure_ids(df: pd.DataFrame) -> pd.DataFrame:
    # Normalize common id/team columns if missing
    alias = {
        "home":"home_abbr","away":"away_abbr",
        "home_team":"home_abbr","away_team":"away_abbr",
        "homeTeam":"home_abbr","awayTeam":"away_abbr",
        "game_id":"msf_game_id","gid":"msf_game_id"
    }
    for src, dst in alias.items():
        if src in df.columns and dst not in df.columns:
            df = df.rename(columns={src: dst})
    if "msf_game_id" not in df.columns:
        if {"home_abbr","away_abbr"}.issubset(df.columns) and "game_start" in df.columns:
            df["msf_game_id"] = (
                df["home_abbr"].fillna("") + "_" +
                df["away_abbr"].fillna("") + "_" +
                df["game_start"].fillna("")
            )
        else:
            df["msf_game_id"] = range(1, len(df)+1)
    return df

def load_best_source() -> tuple[pd.DataFrame,str]:
    if MARKET.exists():
        return pd.read_csv(MARKET), "market"
    if ELO.exists():
        return pd.read_csv(ELO), "elo"
    print("[FATAL] Neither out/week_with_market.csv nor out/week_with_elo.csv exist.", file=sys.stderr)
    sys.exit(1)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--force", action="store_true", help="Rebuild predictions even if it already exists")
    args = ap.parse_args()

    if PREDS.exists() and not args.force:
        # Even if it exists, make sure it has a prob column; repair if needed.
        df = pd.read_csv(PREDS)
        if has_prob(df):
            print("[OK] out/week_predictions.csv already exists and has a probability column.")
            return
        print("[WARN] Existing out/week_predictions.csv lacks probability; repairing...")
    else:
        df, why = load_best_source()
        print(f"[INFO] Building predictions from {why} source.")

    df = ensure_ids(df)

    if not has_prob(df):
        # Try Elo synthesis; else fallback to 0.5
        if not synthesize_from_elo(df):
            df["p_home_model"] = 0.5
            print("[WARN] No prob/Elo cols found; using p_home_model = 0.5")

    PREDS.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(PREDS, index=False)
    # Report which prob column ended up present
    for c in ("p_home","p_home_model","cal_platt"):
        if c in df.columns:
            print(f"[OK] Wrote {PREDS} with probability column: {c} (rows={len(df)})")
            break

if __name__ == "__main__":
    main()
