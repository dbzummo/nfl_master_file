#!/usr/bin/env python3
import pandas as pd
from pathlib import Path

BASE = Path("out/week_with_elo.csv")
ODDS = Path("out/odds_week.csv")
OUT  = Path("out/week_with_market.csv")

NAME2ABBR = {
    "arizona cardinals":"ARI","atlanta falcons":"ATL","baltimore ravens":"BAL","buffalo bills":"BUF",
    "carolina panthers":"CAR","chicago bears":"CHI","cincinnati bengals":"CIN","cleveland browns":"CLE",
    "dallas cowboys":"DAL","denver broncos":"DEN","detroit lions":"DET","green bay packers":"GB",
    "houston texans":"HOU","indianapolis colts":"IND","jacksonville jaguars":"JAX","kansas city chiefs":"KC",
    "los angeles chargers":"LAC","la chargers":"LAC","los angeles rams":"LAR","la rams":"LAR",
    "las vegas raiders":"LV","oakland raiders":"LV","miami dolphins":"MIA","minnesota vikings":"MIN",
    "new england patriots":"NE","new orleans saints":"NO","new york giants":"NYG","ny giants":"NYG",
    "new york jets":"NYJ","ny jets":"NYJ","philadelphia eagles":"PHI","pittsburgh steelers":"PIT",
    "san francisco 49ers":"SF","sf 49ers":"SF","seattle seahawks":"SEA","tampa bay buccaneers":"TB",
    "tennessee titans":"TEN","washington commanders":"WAS","washington football team":"WAS",
}

def to_abbr(x):
    if pd.isna(x): return x
    s = str(x).strip()
    a = NAME2ABBR.get(s.lower())
    return a if a else s  # pass through if already an abbr like "GB"

def need(colnames, *cols):
    missing = [c for c in cols if c not in colnames]
    if missing:
        raise SystemExit(f"[FATAL] Missing required columns: {missing}")

def main():
    if not BASE.exists(): raise SystemExit("[FATAL] baseline not found: out/week_with_elo.csv")
    base = pd.read_csv(BASE)

    if not ODDS.exists():
        print("[WARN] No odds file; passing through baseline.")
        base.to_csv(OUT, index=False)
        print(f"[OK] Wrote {OUT} (rows={len(base)})")
        return

    odds = pd.read_csv(ODDS)

    # Ensure baseline has home/away abbreviations
    need(base.columns, "home_abbr","away_abbr")
    base = base.copy()
    base["home_abbr"] = base["home_abbr"].astype(str).str.strip()
    base["away_abbr"] = base["away_abbr"].astype(str).str.strip()
    base["pair_key"]  = base[["home_abbr","away_abbr"]].apply(lambda r: "|".join(sorted([r[0], r[1]])), axis=1)

    # Normalize odds names to abbreviations; ensure columns exist
    if "home_abbr" not in odds.columns or "away_abbr" not in odds.columns:
        # Try common alternatives (full names)
        for cand in ("home_team","hometeam","home"):
            if cand in odds.columns: odds["home_abbr"] = odds[cand]
        for cand in ("away_team","awayteam","away"):
            if cand in odds.columns: odds["away_abbr"] = odds[cand]
        if "home_abbr" not in odds.columns or "away_abbr" not in odds.columns:
            raise SystemExit("[FATAL] Odds file lacks team columns I can normalize.")

    odds = odds.copy()
    odds["home_abbr"] = odds["home_abbr"].map(to_abbr).astype(str).str.strip()
    odds["away_abbr"] = odds["away_abbr"].map(to_abbr).astype(str).str.strip()

    # Keep only the columns we need; tolerate missing market_p_home (we’ll still join)
    keep = ["home_abbr","away_abbr","market_p_home","ml_home","ml_away","book_count","commence_time"]
    keep = [c for c in keep if c in odds.columns]
    odds = odds[keep]
    odds["pair_key"] = odds[["home_abbr","away_abbr"]].apply(lambda r: "|".join(sorted([r[0], r[1]])), axis=1)

    # Pick one odds row per pair_key (e.g., most books). If book_count missing, just take first.
    if "book_count" in odds.columns:
        odds = odds.sort_values(["pair_key","book_count"], ascending=[True, False]).drop_duplicates("pair_key")
    else:
        odds = odds.drop_duplicates("pair_key")

    # Merge unordered pairs; we’ll fix orientation after merge
    out = base.merge(odds, on="pair_key", how="left", suffixes=("", "_mkt"))

    # Align market probability to baseline home team
    if "market_p_home" in out.columns:
        def align(row):
            # If odds home matches base home, keep as-is; if swapped, flip p
            if pd.isna(row.get("home_abbr_mkt")) or pd.isna(row.get("away_abbr_mkt")):
                return row["market_p_home"]
            return row["market_p_home"] if row["home_abbr_mkt"] == row["home_abbr"] else (1 - row["market_p_home"])
        out["market_p_home"] = out.apply(align, axis=1)

    # Diagnostics
    base_pairs = set(base["pair_key"])
    odds_pairs = set(odds["pair_key"])
    matched = len(base_pairs & odds_pairs)
    print(f"[DEBUG] Join candidates: base={len(base_pairs)} odds={len(odds_pairs)} matched={matched}")

    out.to_csv(OUT, index=False)
    has_mkt = "market_p_home" in out.columns and out["market_p_home"].notna().any()
    print(f"[OK] Wrote {OUT} (rows={len(out)}) | market_p_home present: {has_mkt}")

if __name__ == "__main__":
    main()
